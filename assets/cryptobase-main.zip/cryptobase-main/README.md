# cryptobase

CryptoBase - Flutter Cryptocurrency Price Tracker Complete App

|| Flutter Speed Code
|| http: Rest Api
|| Json
|| Flutter ListView
|| Flutter Custom Class
|| Recurring Functions
|| Neumorphism UI

CoinGecko Api: https://www.coingecko.com/en/api
http Package: https://pub.dev/packages/http
Music: https://www.bensound.com
